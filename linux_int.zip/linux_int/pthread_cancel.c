#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
 
pthread_t id; // creating thread id
 
void *thread2(void *p)
{
int t;
printf("Thread has been created\n");
printf("Thread id is: %lu\n",id);
t = pthread_cancel(id); //cancelling thread
if(t == 0)
{
printf("Thread cancelled itself\n");
}
return NULL;
}
 
int main()
{
printf("Creating thread\n");
int ret = pthread_create(&id,NULL,thread2,NULL);
pthread_join(id,NULL);
return 0;
}

