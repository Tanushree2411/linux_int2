#include<stdio.h>
#include<string.h> //fun def of own

int main()
{
const char str1[10]="linux";
const char str2[10];
mymemcpy(str1,str2,10);
printf("string in str2 is %s\n",str2);
return 0;
}

void mymemcpy(char *src,char *dest,int count)
{
int i;
for(i=0;i<count;i++)
{
*dest=*src;
dest++;
src++;
}
}



