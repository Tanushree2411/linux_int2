#include<pthread.h>
static void* threadfun(void *arg)

{
char *s =(char *)arg;
printf("%s",s);
//return(void *)strlen(s);
return 0;
}
int main(int argc,char *argv[])
{
pthread_t t1;
//void *res;
int s;
s=pthread_create(&t1,NULL,threadfun,"hello world");
printf("meassage from main\n");
sleep(3);
//pthread_join(t1,&res);
//printf("thread returned %ld",(long)res);//other code
exit(0);
}
