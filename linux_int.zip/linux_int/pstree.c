#include<stdio.h> 
#include<unistd.h> 
int main() 
{ 
execlp("pstree","pstree",NULL); 
return 0; 
}

