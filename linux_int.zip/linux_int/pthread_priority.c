#include<pthread.h>
#include<stdio.h>
void *my(void *t)
{
printf("\n:i am in %d thread \n",(int *)t);
}
main()
{
pthread_t tid;
struct sched_param param;
int priority,policy,ret;
ret=pthread_getschedparam(pthread_self(),&policy,&param); //fun provides policy and priority of particular thread(first arg(here main)) here process itself is a thread copying policy into struct param,third arg is struct sched_param for future extension so used struct insted of direct int
if(ret !=0)
perror("getschedparam");
printf("\n....................main thread.........\n policy: %d\t priority: %d\n",policy,param.sched_priority);
policy = SCHED_FIFO;
param.sched_priority=3; //can assign from 1 to 99
ret=pthread_setschedparam(pthread_self(),policy,&param);
if(ret !=0)
perror("getschedparam");
ret=pthread_getschedparam(pthread_self(),&policy,&param);
if(ret !=0)
perror("getschedparam");
printf("\n...main thread\n policy : %d\t priority : %d\n",policy,param.sched_priority);
//this happen of changing priorites nly when you are a root user
}



