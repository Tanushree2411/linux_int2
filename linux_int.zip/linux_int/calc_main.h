double mean(double,double);
double sub(double,double);
