#include<stdio.h>
#include<string.h>
int main()
{
const char str[]="linuxkernel.com";
const char ch='A';
printf("string before set is %s\n",str);
memset(str,ch,strlen(str));
printf("string after set is %s\n",str); //array itself is address
return 0;
}
/**#include<stdio.h>
#include<string.h>



int main()
{
const char str[]="Li";
const char ch='#';



printf("String before set/initialization is %s\n",str);
memset(str,ch,strlen(str));
printf("String after set is %s\n",str);
return 0;
}*/
