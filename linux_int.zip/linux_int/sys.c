#include<stdio.h>
#include<stdlib.h>
#include<string.h>



int main(){



char buff_comm[5];
strcpy(buff_comm,"ls -l");



printf("system() library function uses fork() to create a child process");
printf("child process creates execl command which loads and run new program provided by the system() argument\n");
printf("%d",system(NULL));// if buff inplace of null it will return 0
return 0;
}
