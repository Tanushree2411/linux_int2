#include<stdio.h> 
#include<fcntl.h> 
#include<sys/types.h>
#include<sys/stat.h> 
#include<unistd.h> 
#include<stdlib.h> 
int main(){ 
 int fd;
 fd=open("asg1.c",O_RDONLY,0777); 
 printf("Inherit File Descriptor: %d",fd);  
} 

