#include<pthread.h>
#include<unistd.h>
#include<stdio.h>


void *thread()
{
printf("entered the thread");
}
main()
{
pthread_t p1;
pthread_create(&p1,NULL,thread,NULL);
printf("main executed");

pthread_exit(NULL); //stops executing main
printf("main executed again");
}


