#include<stdio.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>
#include<stdlib.h>
int main()
{
int pid;
int status;

printf("patent %d",getpid());
pid=fork();
if(pid==0)
{
printf("child %d",getpid());
sleep(2);
exit(0);
}
printf("patent reportinf exit of child whoise pid is %d",waitpid(pid,&status,0));
return 0;
}
