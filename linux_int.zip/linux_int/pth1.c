#include<pthread.h>
#include<unistd.h>
#include<stdio.h>
void * start1(void *arg)
{
int i;
for(i=0;i<100;i++)
printf("thd of con1\n");
}
void * start2(void *arg)
{
int i;
for(i=0;i<100;i++)
printf("** thd of con2\n");
}
main()
{
pthread_t pt1,pt2;
//getchar();
pthread_create(&pt1,NULL,start1,NULL);
pthread_create(&pt2,NULL,start2,NULL);
getchar();
printf("end of main thread");
}
