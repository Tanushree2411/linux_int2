#include<stdio.h>
#include<string.h>

int main()
{
char buf1[10];
char buf2[10];
int ret;
memcpy(buf1,"madam",5);
memcpy(buf2,"mada",5);
ret=memcmp(buf1,buf2,5);
if(ret>0)
{
printf("buf1 is gretaer than buf2");
}
else if(ret<0)
{
printf("buf1 is less than buf2");
}
else
printf("buf1 is equal to buf2");
return 0;
}

