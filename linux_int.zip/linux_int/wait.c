#include<stdio.h>
#include<sys/types.h>
#include<sys/wait.h>
int main()
{
pid_t pid1; //pid_t data types of pids
pid1=fork();
if(pid1==0)//child
{
sleep(5);
printf("i am child with delay of 5 sec my child pro pid= %d",getpid());
} 
else //op -1 if no child pid
{
int pid2;//store return value from wait()
printf("i am parent pro pid %d",getpid());
pid2=wait(0);//on return pid of terminated chold
printf("parent saying..child %d exited/yerminated ",pid2);
printf("I am parent process pro pid %d",getpid());

}
return 0;
}


