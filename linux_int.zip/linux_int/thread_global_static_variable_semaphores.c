#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<semaphore.h>
int sharedvar=5;  //shared variables
sem_t my_sem; //create semaphore
void *thread_inc(void *arg)
{
sem_wait(&my_sem);//take semaphore //locking
printf("enrering thread inc\n");
sharedvar=sharedvar+2;//critical sec
sem_post(&my_sem); //release semaphore
printf("after inc=%d\n",sharedvar);
}

void *thread_dec(void *arg)
{
sem_wait(&my_sem);
printf("entering thread dec\n");
sharedvar=sharedvar-2;
sem_post(&my_sem); 

printf("after dec=%d\n",sharedvar);
}
int main()
{
pthread_t thread1,thread2;
sem_init(&my_sem,0,1);
pthread_create(&thread1,NULL,thread_inc,NULL);
pthread_create(&thread2,NULL,thread_dec,NULL);
pthread_join(thread1,NULL);
pthread_join(thread2,NULL);
printf("sharedvar=%d\n",sharedvar);
return 0;
}
