#include<pthread.h>
#include<stdio.h>
pthread_once_t once=PTHREAD_ONCE_INIT;
void *myinit()
{
printf("\n i am in init fun\n");
}

void *mythread(void *t)
{
printf("\n: i am in mythread: %d\n",(int*)t);
pthread_once(&once,(void *)myinit);
printf("\n exit from myhtread: %d\n",(int*)t);
}

int main()
{
pthread_t thread,thread1,thread2;
pthread_create(&thread,NULL,mythread,(void*)1);
pthread_create(&thread,NULL,mythread,(void*)2);
pthread_create(&thread,NULL,mythread,(void*)3);

printf("exit from main");
pthread_exit(NULL);
}
