#include<pthread.h>
#include<stdio.h>




void functi2(){
printf("The thread is executing\n");
sleep(5);
printf("The thread is going to end\n");
}



int main()
{
pthread_t p1;
printf("Created thread\n");
pthread_create(&p1,NULL,functi2,NULL);
sleep(1);
printf("Main task end\n");
pthread_exit(NULL);
}
