#include<pthread.h>
pthread_t tid;

void* thread1(void *arg)
{
printf("new created thread is executing");
return NULL;
}
 int main(void)
{
int ret=pthread_create(&tid,NULL,thread1,NULL);
if(ret)
printf("thread not created");
else
printf("thread is created");
sleep(2);
return 0;
}
