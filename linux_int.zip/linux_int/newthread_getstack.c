#include<pthread.h>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
//#include<sys/main.h>
void* proc(void* param)
{
sleep(2);
return 0;
}
int main()
{
pthread_attr_t attr;
pthread_t id;
void *stk;
size_t siz;
int err;
size_t my_stksize= 0x1000000;
void * my_stack;
pthread_attr_init(&attr);
pthread_attr_getstacksize(&attr,&siz);//fetching and reading adrss //takes 3 args(attributes,addres,size)
pthread_attr_getstackaddr(&attr,&stk);
printf("default address = %08x defaukt size=%d",stk,siz);//size pritning becoz itys predifined by pthread lib and o address bexo we are printing it before creating a thread
my_stack=(void*)malloc(my_stksize);
pthread_attr_setstack(&attr,my_stack,my_stksize);
pthread_create(&id,&attr,proc,NULL);
pthread_attr_getstack(&attr,&stk,&siz);
printf("newly defined stack addr= %08x and size is %d",stk,siz);
sleep(3);
return 0;
}

