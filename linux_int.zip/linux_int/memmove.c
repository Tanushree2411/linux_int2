#include<stdio.h>
#include<string.h>
int main()
{
char dest[]="oldstring";
const char src[]="newstring";
printf("b4 mov dest = %s and src is %s\n",dest,src);
memmove(dest,src,5);
printf("after mov dest = %s and src is %s\n",dest,src);
return 0;
}

