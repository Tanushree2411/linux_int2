/*#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
pthread_t tid;

void *thr_fun(void *arg)
{
pid_t pid;//process id
pthread_t tid;//thread id
pid=getpid();
tid=pthread_self(); //print calling thread_id
printf("pid %u tid %u",(unsigned int)pid,(unsigned int)tid);
return 0;
}

int main()
{
int err;
err=pthread_create(&tid,NULL,thr_fun,NULL);
if(err!=0)
{
printf("cant create rhhread %d",strerror(err));
}
while(1)
exit(0);
}*/



#include<stdio.h>
#include<pthread.h>



pthread_t tid;
void *thr_fn(void *arg){



pid_t pid;
pthread_t tid;
pid=getpid();
tid=pthread_self();
printf("pid %u tid %u\n",(unsigned int)pid,(unsigned int)tid);
return 0;
}



int main(){



int err;
err=pthread_create(&tid,NULL,thr_fn,NULL);
if(err!=0){
printf("can't create thread:%s\n",strerror(err));}
while(1);
exit(0);
}

